from django.db import models

class Car(models.Model):
    make = models.CharField(max_length=50)
    carmodel = models.CharField(max_length=50)
    rent = models.TextField(blank = True)
    def __str__(self): 
        return self.make + ' ' + self.carmodel